// Learn more https://docs.expo.io/guides/customizing-metro
const { getDefaultConfig } = require('expo/metro-config');
const { withNativeWind } = require('nativewind/metro');

/** @type {import('expo/metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

// Apply NativeWind transformer
// This processes className on React Native components for all platforms
module.exports = withNativeWind(config, { 
  input: './app/global.css',
});
