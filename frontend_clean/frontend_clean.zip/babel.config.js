// Lokasi: babel.config.js (di root folder)

module.exports = function (api) {
  api.cache(true);
  return {
    presets: ["babel-preset-expo"],
    plugins: [
      // Plugin untuk NativeWind (Tailwind)
      "nativewind/babel",
      
      // Plugin untuk Reanimated
      // PENTING: Ini harus menjadi plugin yang terakhir di dalam array.
      "react-native-reanimated/plugin", 
    ],
  };
};